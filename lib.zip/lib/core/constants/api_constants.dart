
class ApiConstants {
  static const baseUrl = 'https://api.mytravaly.com/public/v1/';
  static const authToken = '71523fdd8d26f585315b4233e39d9263';
}
