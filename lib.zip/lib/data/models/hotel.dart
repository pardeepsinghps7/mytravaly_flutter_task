class Hotel {
  final String id;
  final String name;
  final String city;
  final String state;
  final String country;
  final String code;
  final String propertyUrl;
  final String? imageUrl;

  Hotel({
    required this.id,
    required this.name,
    required this.city,
    required this.state,
    required this.country,
    required this.code,
    required this.propertyUrl,
    this.imageUrl,
  });

  factory Hotel.fromJson(Map<String, dynamic> json) {
    return Hotel(
      id: json['id']?.toString() ?? '',
      name: json['propertyName'] ?? json['name'] ?? 'Unknown',
      city: json['city'] ?? '',
      state: json['state'] ?? '',
      country: json['country'] ?? '',
      code: json['propertyCode']?.toString() ?? '',
      propertyUrl: json['propertyUrl'] ?? '',
      imageUrl: json['image'] ?? json['imageUrl'],
    );
  }
}
